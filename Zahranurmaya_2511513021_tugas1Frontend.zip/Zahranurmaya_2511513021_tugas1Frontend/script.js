const showBioBtn = document.getElementById("showBioBtn");
const profileName = document.getElementById("profileName");
const profileBio = document.getElementById("profileBio");
const themeButtons = document.querySelectorAll(".theme-btn");
const noteForm = document.getElementById("noteForm");
const noteInput = document.getElementById("noteInput");
const noteList = document.getElementById("noteList");

let totalNotes = 1;

function showBio() {
  const biodata = {
    nama: "Nama: Zahra Nurmaya",
    panggilan: "Nama Panggilan: Zahra",
    ttl: "Tempat, Tanggal Lahir: Jakarta, 26 Januari 2006",
    jurusan: "Jurusan: Teknik Komputer",
    fakultas: "Fakultas: Teknologi Informasi",
    universitas: "Universitas: Universitas Andalas",
    nim: "NIM: 2511513021",
  };

  profileName.textContent = biodata.nama;
  profileBio.innerHTML = `
    ${biodata.panggilan}<br>
    ${biodata.ttl}<br>
    ${biodata.jurusan}<br>
    ${biodata.fakultas}<br>
    ${biodata.universitas}<br>
    ${biodata.nim}
  `;
}

function changeTheme(themeName) {
  document.body.classList.remove("theme-green", "theme-pink");

  if (themeName !== "blue") {
    document.body.classList.add(`theme-${themeName}`);
  }
}

function addNote(event) {
  event.preventDefault();

  const noteText = noteInput.value.trim();

  if (noteText === "") {
    noteInput.focus();
    return;
  }

  totalNotes += 1;

  const newItem = document.createElement("li");
  newItem.textContent = `${totalNotes}. ${noteText}`;
  noteList.appendChild(newItem);

  noteInput.value = "";
  noteInput.focus();
}

showBioBtn.addEventListener("click", showBio);

themeButtons.forEach(function (button) {
  button.addEventListener("click", function () {
    const selectedTheme = button.dataset.theme;
    changeTheme(selectedTheme);
  });
});

noteForm.addEventListener("submit", addNote);
